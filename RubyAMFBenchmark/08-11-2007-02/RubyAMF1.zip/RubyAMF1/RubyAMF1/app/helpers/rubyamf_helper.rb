class RubyAMFHelper


end
