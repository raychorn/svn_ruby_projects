RAILS_ROOT = 'Z:\ruby\Ruby In Steel\RubyAMFBenchmark\RubyAMF1\RubyAMF1'
require 'Z:\ruby\Ruby In Steel\RubyAMFBenchmark\RubyAMF1\RubyAMF1\config\boot.rb'
require 'commands/server'
